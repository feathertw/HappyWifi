package com.example.testlogin;

import org.apache.http.message.BasicNameValuePair;

public class Parameters {
	
	public static School getSchool(){
		
		School school = new School();
		
		school.name="NCKU";
		school.mail="@mail.ncku.edu.tw";
		school.accountPara="username";
		school.passwordPara="password";
		
		school.loginHttps="https://wlan.ncku.edu.tw/login.html";
		school.logoutHttps="https://wlan.ncku.edu.tw/logout.html";
		school.loginAppearValue="Login Successful";
		school.logoutAppearValue="To complete the log off process";
		
		school.LoginDataPair.add(new BasicNameValuePair("buttonClicked", "4"));
		school.LogoutDataPair.add(new BasicNameValuePair("userStatus", "1"));
		school.LogoutDataPair.add(new BasicNameValuePair("err_flag", "0"));
		school.LogoutDataPair.add(new BasicNameValuePair("err_msg", ""));
		
		school.ssid.add("NCKU-WLAN");
		
		return school;
	}
}




