package com.example.testlogin;

import java.util.List;

import org.apache.http.message.BasicNameValuePair;

import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

	
	private String account = "XXXXXX@XXXXXXXXXX";
	private String password = "XXXXXXXXXX";
	
	
	private int q;
	private TextView tview;
	private School school;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		WifiManager wifiManager=(WifiManager)getSystemService(Context.WIFI_SERVICE);
		List<ScanResult> wifiScanlist=wifiManager.getScanResults();
		
		for(ScanResult s : wifiScanlist) {
			Log.i("xxxxx","Wifi ssid:"+s.SSID+" level:"+s.level);
		}
		List<WifiConfiguration> list = wifiManager.getConfiguredNetworks();	
		int networkId=-1;
		for (WifiConfiguration i : list) {
			Log.i("xxxxx","SSID:" + i.SSID + "networkId:"+ i.networkId);
		}
		Log.i("xxxxx",""+wifiManager.getConnectionInfo() );
		
		LinearLayout v=new LinearLayout(this);
		Button blogin=new Button(this);
		Button blogout=new Button(this);
		Button bcheck=new Button(this);
		tview=new TextView(this);
		blogin.setText("LOGIN");
		blogout.setText("LOGOUT");
		bcheck.setText("CHECK");
		tview.setText("view");
		
		
		v.addView(blogin);
		v.addView(blogout);
		v.addView(bcheck);
		v.addView(tview);
		setContentView(v);
		
		school=Parameters.getSchool();
		school.LoginDataPair.add(new BasicNameValuePair(school.accountPara, account));
		school.LoginDataPair.add(new BasicNameValuePair(school.passwordPara, password));
		
		blogin.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				new Thread(new Runnable() {
					public void run() {
						new Thread(new Runnable() {
							public void run() {
								q++;
								final String result = MyConnectHttp.post_https(school.loginHttps, school.LoginDataPair);
								final String sresult = MyConnectHttp.get_http("http://ctc8631.qov.tw/internet_check.html");
								Log.i("xxx1",result);
								Log.i("xxx2",sresult);
								tview.post(new Runnable(){
				    				public void run(){
				    					if(sresult!=null && sresult.indexOf( "*FOR_ANDROID_NCKU_WIFI*" ) != -1){
											tview.setText(q+"online");
										}
										else{
											tview.setText(q+"offline");
										}
				    				} 
								});
							
							}
						}).start();
					}
				}).start();

			}
		});
		blogout.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				new Thread(new Runnable() {
					public void run() {
						new Thread(new Runnable() {
							public void run() {
								q++;
								final String result = MyConnectHttp.post_https(school.logoutHttps, school.LogoutDataPair);
								final String sresult = MyConnectHttp.get_http("http://ctc8631.qov.tw/internet_check.html");
								Log.i("xxx3",result);
								Log.i("xxx4",sresult);
								tview.post(new Runnable(){
				    				public void run(){
				    					if(sresult!=null && sresult.indexOf( "*FOR_ANDROID_NCKU_WIFI*" ) != -1){
											tview.setText(q+"online");
										}
										else{
											tview.setText(q+"offline");
										}
				    				} 
								});
							
							}
						}).start();						
					}
				}).start();
			}
		});
		bcheck.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				new Thread(new Runnable() {
					public void run() {
						q++;
						final String sresult = MyConnectHttp.get_http("http://ctc8631.qov.tw/internet_check.html");
						Log.i("xxx5",sresult);
						tview.post(new Runnable(){
		    				public void run(){
		    					if(sresult!=null && sresult.indexOf( "*FOR_ANDROID_NCKU_WIFI*" ) != -1){
									tview.setText(q+"online");
								}
								else{
									tview.setText(q+"offline");
								}
		    				} 
						});
					
					}
				}).start();
	
			}
		});
	}

}
